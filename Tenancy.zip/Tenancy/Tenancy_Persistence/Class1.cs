﻿namespace Tenancy_Persistence
{
    public class Class1
    {

    }
}
