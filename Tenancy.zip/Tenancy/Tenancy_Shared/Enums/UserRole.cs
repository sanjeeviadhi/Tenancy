﻿namespace Tenancy_Shared.Enums
{
    public enum UserRole
    {
        Shared = 0,
        Isolated = 1

    }
}
